# LOVART PROMPT — UniFlow Mobile UI Design System
## 3 Planches A3 (420×297mm, 150dpi, fond blanc)

---

## CONTEXTE DE MARQUE

**Produit** : UniFlow — Application universitaire mobile (Android)
**Éditeur** : KERNEL FORGE
**Palette officielle** :
- Primaire : Bleu marine `#1E3A8A`
- Secondaire : Teal `#0D9488`
- Dégradé header : `#1E3A8A` → `#0D9488`
- Fond app : Blanc `#FFFFFF` / Gris très clair `#F8FAFF`
- Texte principal : `#1E293B`
- Accent : Indigo `#4F46E5`

**Logo** : Fichier joint `uniflow_logo_horizontal.png` — NE PAS MODIFIER le logo.
**Mascottes** :
- **Uni** et **Archlord** sont des personnages déjà finalisés avec leurs propres images PNG/WebP.
- **NE PAS les dessiner, ni les recréer, ni les générer.** Leurs designs sont fixés.
- Partout où une mascotte doit apparaître dans un écran, placer un **rectangle placeholder arrondi** avec le label centré ("MASCOTTE UNI" ou "MASCOTTE ARCHLORD") en gris clair, bordure pointillée bleue, même taille que la mascotte attendue. L'intégration réelle se fait côté développement.

**Style visuel** :
- Clean, minimal, moderne
- Cards arrondies (border-radius 20-28px)
- Ombres douces bleutées
- Illustrations 3D colorées (voir refs `ref_grocery_app.jpeg`, `ref_dashboard.jpeg`)
- Bottom navigation épurée
- Typography bold pour les titres, medium pour le corps

---

## PLANCHE 1 — FLUX D'AUTHENTIFICATION (A3 paysage)

Disposer côte à côte, avec annotations :

### Écran 1.1 — Splash Screen
- Fond dégradé vertical `#1E3A8A` → `#0D9488`
- Logo `uniflow_logo_horizontal.png` centré (blanc)
- Cercles décoratifs semi-transparents en arrière-plan
- Animation de chargement subtile (3 dots pulsants)

### Écrans 1.2 à 1.5 — Onboarding (4 pages)
Chaque page : fond dégradé couleur différente (bleu, teal, indigo, bleu foncé)
- Illustration éducative grande (60% hauteur), dans une card verre arrondie
- Titre bold blanc 24px
- Sous-titre blanc 70% 13px
- **En bas de chaque page** : deux rectangles placeholders côte à côte — gauche : zone "ARCHLORD" (bordure pointillée bleue), droite : zone "UNI" (bordure pointillée teal) — hauteur ~100px. **Ne pas dessiner les personnages.** Une bulle de dialogue stylisée (fond blanc, ombre) flotte au-dessus du placeholder actif.
- Dots de pagination et bouton "Suivant" blanc arrondi
- **Logo** en pill glassmorphism en haut à gauche (pas de texte, l'image du logo)
- Bouton "Passer" en haut à droite

### Écran 1.6 — Login
- Header dégradé `#1E3A8A`→`#0D9488` (40% hauteur) avec un placeholder "UNI" (zone réservée, bordure pointillée teal) à droite
- Sheet blanche arrondie en bas (60% hauteur)
- Sélecteur "Universitaire / Indépendant" (deux chips)
- Champs email + mot de passe avec icônes
- Bouton CTA dégradé bleu→teal "Se connecter"
- Lien "Inscription" et "Mot de passe oublié"

---

## PLANCHE 2 — DASHBOARD & NAVIGATION PRINCIPALE (A3 paysage)

### Écran 2.1 — Dashboard (vue étudiant)
- Header dégradé `#1E3A8A`→`#0D9488`
  - Logo UniFlow blanc en haut à gauche
  - Avatar utilisateur à droite
  - "Bonjour Ravel 👋" en titre
  - Zone placeholder "UNI" (rectangle arrondi, bordure pointillée teal, ~80×80px) flottante en haut à droite du header — **ne pas dessiner le personnage**
- Corps fond blanc/gris très clair
- Row de 4 StatCards arrondies avec ombres (Présences, Notes, Devoirs, XP)
- Section "Prochains cours" avec cards bleues arrondies
- Section "Badges récents" : rangée horizontale de médailles colorées
- Bottom navigation : 5 items (Accueil, Cours, Messagerie, Quêtes, Profil)

### Écran 2.2 — Cours / Emploi du temps
- Header bleu avec titre "Mon emploi du temps"
- Filtres semaine (chips horizontaux)
- Liste de cours avec cards colorées selon la matière
- Chaque card : matière, professeur, salle, heure, barre de progression

### Écran 2.3 — Profil utilisateur
- Header dégradé avec grand avatar circulaire centré
- Nom + rôle + université
- Barre XP avec niveau gamifié
- Grille de badges débloqués (images depuis bucket Appwrite)
- Stats (présences %, notes moyennes, devoirs rendus)

### Écran 2.4 — Notifications
- Header bleu "Notifications"
- Cards de notifications avec icônes colorées
- Types : cours annulé (rouge), devoir à rendre (orange), badge débloqué (violet), message (bleu)

---

## PLANCHE 3 — GAMIFICATION & MESSAGERIE (A3 paysage)

### Écran 3.1 — Page Badges (100 badges)
- Header dégradé avec titre "Mes Badges" + compteur "12/100"
- Zone placeholder "UNI" dans le header (rectangle arrondi, bordure pointillée teal) — **ne pas dessiner le personnage**
- Onglets catégories : Assiduité | Académique | Social | Spécial | Communauté
- Grille 4×N de badges :
  - Badge débloqué : illustration couleur + anneau brillant + nom
  - Badge verrouillé : grisé + cadenas
  - Chaque badge a sa propre image unique (from Appwrite bucket)
- Card détail badge (modal bottom sheet) : illustration grande, description, critère, date obtention

### Écran 3.2 — Page Quêtes (dynamiques, auto-reset)
- Header dégradé avec titre "Quêtes" + badge XP total
- Onglets : Hebdomadaires | Mensuelles | Annuelles
- Chaque quête = card arrondie :
  - Icône colorée + titre + description
  - Barre de progression animée
  - Récompense XP en badge
  - Countdown jusqu'au reset
- Widget "Meilleur de la semaine" en haut avec classement top 3 (avatars + noms)

### Écran 3.3 — Liste de messagerie
**Inspiré du style `ref_messaging.jpeg`** (bulles rondes colorées, avatars circulaires) adapté aux couleurs UniFlow :
- Header dégradé `#1E3A8A` avec SearchBar blanche
- Liste de conversations :
  - Avatar circulaire coloré à gauche
  - Nom + aperçu message
  - Timestamp + badge nb messages non lus (bleu)
  - Dernière activité

### Écran 3.4 — Conversation (fil de messages)
**Style `ref_messaging.jpeg`** adapté bleu/teal :
- Header teal avec nom + statut en ligne + avatar
- Bulles de messages :
  - Envoyées : dégradé `#1E3A8A`→`#0D9488`, texte blanc, à droite avec avatar
  - Reçues : blanc avec ombre douce, texte dark, à gauche avec avatar
  - Support : texte, emoji, audio (player inline), image, sticker
- Bouton envoi circulaire dégradé bleu→teal (comme le FAB rose dans la ref)
- Barre de saisie arrondie avec icône attachment

### Écran 3.5 — Assistant Uni (interface chat IA)
- Header spécial : fond noir profond `#0A0E1A` avec étoiles subtiles
- Zone placeholder "UNI" grande en haut (rectangle arrondi centré, bordure pointillée teal, ~120×120px) — **ne pas dessiner le personnage, laisser la zone réservée**
- Bulle de bienvenue de Uni avec texte contextuel
- Historique conversation : bulles utilisateur (bleu) et Uni (fond blanc avec bordure teal)
- Input avec micro + envoi
- Suggestions rapides en chips horizontaux

---

## CONSIGNES TECHNIQUES POUR LOVART

1. **Format** : 3 fichiers PNG séparés, chacun A3 (4961×3508px à 300dpi) en orientation **paysage**
2. **Disposition** : Écrans mobiles (390×844px ratio iPhone 14) placés horizontalement avec espaces, annotations de noms en dessous
3. **Rendu** : Maquettes haute-fidélité (pas wireframes) — comme si on voyait les vrais screenshots de l'app
4. **Mascottes** : NE PAS dessiner ni generer les personnages Uni et Archlord. Leurs designs sont fixes et seront integres par les developpeurs. Representer leur emplacement par des rectangles placeholders arrondis avec label textuel (ex. "UNI", "ARCHLORD"), bordure pointillee bleue/teal, fond tres legerement teinte.
5. **Logo** : Utiliser `uniflow_logo_horizontal.png` tel quel dans chaque ecran approprie
6. **Coherence** : Meme style, memes couleurs, meme typographie sur les 3 planches
7. **Annotations** : Legeres, en gris, sous chaque ecran (nom + numero)

---

## FICHIERS JOINTS A UPLOADER DANS LOVART

- `uniflow_logo_horizontal.png` — logo officiel (a integrer tel quel dans les ecrans)
- `uniflow_marque.png` — marque/symbole seul
- `kernel_forge.webp` — logo editeur
- `ref_grocery_app.jpeg` — reference style mobile clean
- `ref_dashboard.jpeg` — reference dashboard
- `ref_messaging.jpeg` — reference messagerie (style cible)
- `onboarding_1_bienvenue.webp`, `onboarding_2_univers.webp`, `onboarding_3_connecte.webp` — illustrations existantes (a placer dans les ecrans onboarding)

NOTE : Les fichiers uni_*.webp et archlord_*.webp ne sont PAS a uploader. Les personnages ne doivent pas etre reproduits par Lovart -- des zones placeholders sont prevues a leur place.
