# Prompt pour Claude — Plan de travail UniFlow sur 7 jours

> Copier tout ce fichier dans une conversation Claude. Les passages entre
> crochets `[À COMPLÉTER]` sont à renseigner avant l'envoi (ou Claude les
> signalera comme à confirmer). Rédigé le 21 septembre 2026 par le chef de
> projet, à partir de l'état réel des dépôts et de la base Appwrite.

---

## Ta mission

Tu es directeur de programme d'une équipe étudiante de dix personnes qui
développe **UniFlow**, la plateforme universitaire tout-en-un de la startup
**KERNEL FORGE** (Yaoundé, Cameroun). Produis-moi un **plan de travail sur
7 jours**, du **mardi 22 septembre 2026 (J1) au lundi 28 septembre 2026
(J7)**, organisé en **trois groupes qui travaillent en parallèle** :

1. **Groupe Desktop** — finir l'application de bureau pour qu'elle rattrape
   le web et le mobile.
2. **Groupe Marketing** — faire connaître UniFlow : nouvelle vidéo de
   présentation, diffusion dans les groupes et réseaux, chaîne TikTok.
3. **Groupe Tests** — éprouver l'application mobile et le site web pour
   trouver les erreurs, avec une campagne de simulations ordonnée que tu
   dois **créer, ordonner et expliquer pas à pas**.

Le plan doit être **concret et exécutable** : par jour et par groupe, des
tâches nommées, la personne responsable, le livrable attendu, la durée
estimée, le critère de « terminé ». **N'invente aucun fait** sur le projet :
tout ce que tu dois savoir est ci-dessous ; si une information manque,
écris `[À CONFIRMER]` et pose la question à la fin plutôt que de deviner.
Réponds **en français**, en Markdown, avec des tableaux quand ils aident.

---

## 1. Le projet, tel qu'il est le 21 septembre 2026

UniFlow réunit pour une université : emploi du temps par programme et
niveau, cours et unités d'enseignement, devoirs et rendus, notes, présence
par QR code, bibliothèque de documents, messagerie, forum, notifications,
badges, assistant IA « Uni » (mascotte), et un **espace indépendant** pour
qui n'est pas rattaché à une université (matières, tâches, notes
personnelles). Un seul backend : **Appwrite Cloud** (projet `uniflow`,
région Francfort), une base, un bucket, deux Functions (`uniflow-api`
routeur et `notification-alerts`). Aucun autre service tiers.

### Trois clients, trois états d'avancement

| Client | Dépôt GitHub (organisation `KERNEL-FORGE-G`) | État |
| --- | --- | --- |
| **Web** (React + Vite + TypeScript, PWA) | `uniflow-we` | **v1 en production** : https://uniflow.kernelforge.codes (les adresses internes sont de la forme `/#/…`). Landing, À propos, Équipe, Sentinelle, Tarifs, Présentation, Forum, Contact, **Télécharger** (`/#/download`), connexion / inscription / mot de passe oublié, espace connecté complet (tableau de bord par rôle, cours, emploi du temps, présence QR, devoirs, notes, bibliothèque, messagerie, notifications, forum, profil, réglages, espace indépendant, facturation), **administration** (structure académique, utilisateurs, cours, paiements en attente, rapports, sécurité, réglages, équipe, applications à télécharger). |
| **Mobile** (Flutter, Android) | `uniflow-mobile` | **APK 1.0.0 publié** (87,2 Mo) : https://github.com/KERNEL-FORGE-G/uniflow-apps/releases/tag/uniflow — lien aussi sur la page `/#/download` du site avec l'empreinte SHA-256 et les étapes d'installation. Onboarding, connexion / inscription, tableau de bord par rôle, emploi du temps filtré sur le programme et le niveau de l'étudiant, UE, devoirs, notes, présence QR, bibliothèque, messagerie, forum, notifications, badges, assistant Uni, espace personnel, réglages, suppression de compte, **mode hors ligne complet** (cache local, file d'écritures rejouée, synchronisation en arrière-plan, session conservée — l'objectif affiché est de fonctionner un mois sans réseau). L'APK est signé avec une clé de debug : Android affiche un avertissement à l'installation, c'est connu. |
| **Desktop** (Flutter, Linux / Windows / macOS) | `uniflow-desktop` | **En retard, pas encore publié.** Voir §3 pour l'inventaire exact de ce qui existe et de ce qui manque. 585 tests passent, CI GitHub Actions verte (elle produit déjà une archive Linux). |

### Comptes et rôles — règles non négociables

- L'**inscription libre** (web ou mobile) ne crée que des **étudiants**
  (`STUDENT`) ou des **comptes indépendants** (`PERSONAL`, sans université).
- Une **administration** (`ADMIN`) crée les **enseignants** (`TEACHER`), les
  **délégués** (`DELEGATE`) et peut créer des étudiants de son université.
- Les comptes `ADMIN` sont créés **uniquement** par l'administrateur de la
  plateforme (super-admin `kernel@forge.codes`).
- La preuve du rôle est le **label Appwrite** posé par les Functions ; un
  compte université ne voit jamais l'espace personnel, et inversement.
- **Facturation** : aucun paiement en ligne. Tous les parcours d'abonnement
  renvoient vers WhatsApp **+237 657 635 644** avec un message pré-rempli ;
  l'administration voit les validations de paiement en attente.
- **Visioconférence** : desktop uniquement (serveur LiveKit local, hors
  ligne, le desktop diffuse un lien navigateur local aux participants). Le
  web et le mobile n'en portent aucune.

### Données déjà en base

- Emplois du temps de la **Faculté des Sciences de l'Université de Yaoundé I**
  (557 séances, dont 30 fictives) ; la filière **ICT4D L1** est réelle, les
  emplois du temps **ICT4D L2 et L3 sont fictifs** en attendant les vrais.
- Une **salle de classe de démonstration ICT4D L1** : une administration,
  un enseignant, un délégué, huit étudiants nommés, des cours, devoirs,
  présences et notes.
- Comptes de démonstration (les **mots de passe sont donnés par Ravel**, ils
  ne figurent dans aucun fichier partagé) :

| Compte | Rôle |
| --- | --- |
| `kernel@forge.codes` | Super-admin de la plateforme |
| `administration.ict4d@uniflow.test` | Administration — Faculté des Sciences (ADMIN) |
| `enseignant.ict4d@uniflow.test` | Enseignant (TEACHER) |
| `delegue.ict4d.l1@uniflow.test` | Délégué L1 (DELEGATE) |
| `etudiant.ict4d.l1@uniflow.test`, `etudiant.ict4d.l2@uniflow.test` | Étudiants L1 et L2 |
| `independant@uniflow.test` | Compte indépendant (PERSONAL) |

### Conventions de travail de l'équipe (à rappeler dans le plan)

- Un commit par ensemble cohérent, message en français (sujet + pourquoi),
  poussé après chaque modification importante ; **aucune mention de
  co-auteur**.
- **Toute correction ajoute un test.** Les tests existants doivent rester
  verts (`flutter test`, `node --test`).
- Les commentaires expliquent **pourquoi**, pas quoi.
- Aucun secret (clé, jeton, mot de passe) dans un fichier versionné.
- Le schéma Appwrite a une source unique : `uniflow-we/scripts/appwrite-schema.mjs`.
- La documentation va dans `docs/` de chaque dépôt.

---

## 2. L'équipe et la répartition que je t'impose

Dix membres (liste officielle, page https://uniflow.kernelforge.codes/#/teams) :

| Membre | Rôle dans l'équipe | Groupe pour ces 7 jours |
| --- | --- | --- |
| **NGHOMSI FEUKOUO Ravel** | Chef de projet & architecte (c'est moi) | **Tests** (et arbitrage général) |
| **Aliyatou Rachid Oumou Tourab (« Alia »)** | Cheffe du groupe développement desktop | **Desktop** (responsable) |
| **DJOMGUE Miguel** | Nouveau membre, développeur desktop, arrivé le 21/09 | **Desktop** (en binôme avec Alia) |
| **Tessoh Pekam Marcel** | Chef de la branche marketing (et développeur frontend) | **Marketing** (responsable) |
| **SINENG KENGNI Juvenal** | Développeur frontend multiplateforme — ancien de l'équipe frontend web | **Marketing** |
| `[À COMPLÉTER : autres anciens de l'équipe frontend web, s'il y en a]` | | **Marketing** |
| **Mandeng Judith Oceanne** | Développeuse mobile | **Tests** |
| **FEBNCHAK M. Borelle Sandra** | Développeuse mobile | **Tests** |
| **Meli William** | Développeur backend (APIs & base de données) | **Tests** |
| **HASSANE YOUSSOUF Oumar** | Développeur backend (microservices) | **Tests** |
| **Mokam Ange** | Développeuse backend (SGBD & infrastructure) | **Tests** |

Contraintes de disponibilité : `[À COMPLÉTER : heures par jour et par
personne, cours à éviter, fuseau UTC+1]`. Canal de coordination :
`[À COMPLÉTER : groupe WhatsApp / Discord, heure du point quotidien]`.

---

## 3. Groupe Desktop — Alia + Miguel, « en symbiose »

**But de la semaine : le desktop offre les mêmes services que le web et le
mobile, et un premier binaire est téléchargeable depuis la page
`/#/download` du site.**

Le binôme travaille en **symbiose** : programmation en binôme sur les
morceaux risqués (hors ligne, publication), répartition claire sur les
écrans indépendants, **relecture croisée de chaque commit**, une branche par
sujet fusionnée chaque soir. Miguel découvre le code : prévois pour lui à J1
une prise en main guidée par Alia (architecture, `docs/ADR-001-architecture-desktop.md`,
lancement, tests) et une première tâche bornée le jour même.

### Ce qui existe déjà dans `uniflow-desktop`

Connexion, inscription native (entrée directe dans l'application), mot de
passe oublié ; tableau de bord par rôle ; notifications ; étudiants,
enseignants, programmes, unités d'enseignement, salles ; emploi du temps
(filtres programme / niveau / semestre, export PDF, impression) ; présence
(appel, émission de QR, correction) ; écrans de gestion des devoirs, notes et
bibliothèque (ébauche des devoirs **non revue depuis le 15/09**) ;
**conférences** (visioconférence LiveKit locale : créer / rejoindre, lien
navigateur pour le même réseau, feuille de présence alimentée par les
webhooks, exports PDF et Excel dans `Documents/UniFlow/Présences`) ;
messagerie ; équipe ; comptes ; statistiques ; réglages. Trois écrans sont
des **vitrines sans données** : Structure académique, Paiements, Sentinelle.
Design refait (mascottes Uni et Archlord, barre latérale, composants
`AppDataTable` / `AppButton`, toasts). Menu filtré par rôle et type de compte.

### Les écarts à combler, par ordre d'importance (à planifier sur les 7 jours)

1. **Publier un binaire** : archive Linux (déjà produite par la CI) et
   installateur ou archive **Windows** ; macOS si une machine est disponible
   `[À CONFIRMER]`. Déposer sur la release GitHub et renseigner la plateforme
   desktop dans la collection `app_releases` (page d'administration
   « Applications à télécharger », ou `uniflow-we/scripts/set-app-release.mjs`)
   pour que la page `/#/download` affiche le lien, la taille et le SHA-256.
2. **Mode hors ligne** équivalent au mobile : cache local des données lues,
   file d'écritures rejouée au retour du réseau, session conservée,
   synchronisation en arrière-plan. Le mobile a déjà tout cela dans
   `uniflow-mobile/lib/offline/` (`local_database`, `outbox`, `sync_engine`,
   `session_store`, `background_sync`, `cached_providers`) : transposer, ne
   pas réinventer. Le desktop n'a aujourd'hui que l'indicateur d'état
   `lib/offline/sync_state.dart`.
3. **Écrans absents** par rapport au mobile et au web : forum ; badges ;
   aide / à propos ; vue **étudiant** des devoirs (consulter, rendre un
   devoir) et des notes ; inscription aux UE ; profil (photo, mot de passe) ;
   suppression de compte ; parcours de facturation vers WhatsApp (à la place
   de la vitrine Paiements) ; structure académique réelle (à la place de la
   vitrine). Sentinelle reste une vitrine, c'est voulu.
4. **Devoirs côté enseignant** : revoir et finir `lib/screens/academic_management_screens.dart`
   (création, rendus, notation) contre les mêmes collections que le web.
5. **Visioconférence — l'essai à deux machines n'a jamais été fait** : un
   hôte, un participant sur un second desktop, un participant navigateur par
   le lien du réseau local ; vérifier que la feuille de présence se remplit
   et que les exports sortent. Rédiger le compte rendu dans `docs/`.
6. **Éprouver la restriction par rôle** avec les comptes de la salle de
   classe : chaque rôle ne voit que ce qui le concerne.
7. **Contraste de l'écusson sur l'écran de connexion** : décision à me
   demander (le mobile utilise une plaque blanche derrière le logo).
8. **Qualité** : tests toujours verts, un test par correction, CI verte,
   journal `ETAT-DU-PROJET.md` / `TRAVAUX-RESTANTS.md` mis à jour en fin de
   semaine.

Pour ce groupe, donne un découpage **jour par jour** avec, pour chaque
tâche, qui la porte (Alia, Miguel, ou binôme), une estimation, les
dépendances, et un **jalon intermédiaire à J4** (revue de mi-parcours avec
moi) puis une **démonstration à J7**.

---

## 4. Groupe Marketing — Tessoh (chef) + anciens de l'équipe frontend web

**But de la semaine : UniFlow est vu, compris et téléchargé.** Trois chantiers
imposés :

1. **Nouvelle vidéo de présentation du web et du mobile** (celle qui est en
   ligne sur la page Présentation du site est ancienne) : scénario,
   storyboard, captures d'écran réelles du site en production et de l'APK,
   voix ou sous-titres en français, générique avec logo et mascottes ; deux
   formats — **16:9** (YouTube, LinkedIn, page Présentation du site) et
   **9:16** (TikTok, statuts WhatsApp, Reels). Prévois une relecture par moi
   avant publication.
2. **Partage et annonce du projet** dans les groupes et réseaux : groupes
   WhatsApp et Telegram des facultés et filières de l'UY1 (et des autres
   universités de Yaoundé), LinkedIn (page personnelle et page KERNEL FORGE),
   Facebook, X, communautés tech camerounaises, Discord étudiants. Chaque
   message doit pointer vers le site et vers la page de téléchargement.
   Établis un **calendrier de diffusion** (quel message, quel canal, quel
   jour, qui publie) et un tableau de **suivi des réactions**.
3. **Création de la chaîne TikTok UniFlow** : identité (nom, bio, photo de
   profil avec le logo, bannière), ligne éditoriale (astuces étudiants, mini
   démonstrations de 20-40 s, coulisses de l'équipe, les mascottes Uni et
   Archlord), **cinq premières vidéos publiées avant J7**, calendrier de
   publication pour les deux semaines suivantes.

Matériel déjà disponible, à réutiliser plutôt que refaire :

- Dossier `IMAGES-UNIFLOW/` du projet : logos (principal, écusson, mot-symbole,
  icône), **12 poses d'Uni** et **7 poses d'Archlord** détourées,
  badges, illustrations.
- `POST-LINKEDIN-UNIFLOW.md` (post prêt, 2 784 caractères, avec version
  courte, réponse type aux commentaires et conseils de publication) et
  `MESSAGE-WHATSAPP-UNIFLOW.md` (message de diffusion avec emojis).
- La carte de partage sociale du site (`og-card.jpg`) et la page
  `/#/download` (liens, empreinte, étapes d'installation).
- Les comptes de démonstration pour filmer sans exposer de vraies données.

Indicateurs à suivre chaque jour : téléchargements de l'APK (page de la
release GitHub), inscriptions (nombre de nouveaux comptes, que je fournis),
vues et abonnés TikTok, réactions LinkedIn. Rappelle les règles : ne jamais
publier de mot de passe ni de donnée personnelle d'étudiant, demander
l'accord des personnes filmées, prononcer et écrire **UniFlow** et
**KERNEL FORGE** correctement.

---

## 5. Groupe Tests — Ravel, Judith, Sandra, William, Hassane, Ange

**But de la semaine : trouver les erreurs du mobile et du web avant que le
marketing n'amène du monde.** C'est le groupe pour lequel je te demande le
plus de précision : **crée la liste des simulations à faire absolument,
ordonne-les, et explique comment faire chacune.**

### Ce que doit contenir la campagne

Pour chaque simulation : un identifiant (`S01`, `S02`…), la plateforme
(web, mobile, ou les deux), le compte et le rôle à utiliser, les
préconditions, les **étapes numérotées**, le **résultat attendu**, les
preuves à capturer (capture d'écran, vidéo courte, heure, version), et le
**testeur désigné**. Ordonne les simulations par dépendance et par risque :
d'abord ce qui bloque tout (installation, création de compte, connexion),
puis les parcours quotidiens, puis les cas limites. Répartis-les sur les
7 jours et entre les six testeurs, en tenant compte des téléphones
disponibles `[À COMPLÉTER : modèles Android et versions]` et des navigateurs
(Chrome, Firefox, Edge, Safari si possible, en fenêtre normale **et**
sur petit écran).

### Parcours à couvrir obligatoirement

**Installation et accès**
- Installer l'APK depuis la page `/#/download` (avertissement de source
  inconnue attendu), vérifier l'empreinte SHA-256, premier lancement,
  onboarding (il doit s'afficher à chaque lancement après fermeture).
- Installer le site comme application (PWA) sur téléphone et ordinateur ;
  vérifier que la mise à jour du site se propage.

**Comptes**
- Inscription libre étudiant : université, faculté, filière et niveau
  proposés dynamiquement depuis la base (pas de liste figée), redirection
  directe vers le tableau de bord, e-mail de bienvenue s'il y en a un.
- Inscription d'un compte indépendant, puis utilisation de l'espace
  personnel (matières, tâches, notes) ; vérifier qu'aucun élément
  universitaire n'apparaît.
- Connexion, déconnexion (le bouton de déconnexion sur **chaque** écran qui
  en a un), mot de passe oublié de bout en bout, session conservée après
  fermeture (mobile).
- Création par l'administration d'un enseignant, d'un délégué, d'un
  étudiant ; vérifier que l'inscription libre ne peut créer aucun de ces
  rôles ; qu'un ADMIN ne peut être créé que par le super-admin.
- **Suppression de compte** : toutes les données personnelles disparaissent
  (matières, tâches, inscriptions), la reconnexion échoue.

**Vie académique (avec la salle de classe ICT4D L1)**
- L'emploi du temps d'un étudiant ne montre **que** son programme et son
  niveau ; celui de l'enseignant montre ses cours ; export et impression sur
  le web.
- Devoir complet : l'enseignant crée, l'étudiant reçoit la notification et
  rend, l'enseignant note, l'étudiant voit la note et sa moyenne.
- Présence par QR : l'enseignant ouvre une séance, l'étudiant scanne,
  la liste se met à jour ; cas du QR expiré et de la double lecture.
- Bibliothèque : dépôt, téléchargement, droits (un étudiant d'une autre
  filière ne voit pas le document).
- Forum, messagerie (nouvelle conversation, envoi, réception sur l'autre
  appareil, le bouton d'Uni ne cache jamais le bouton d'envoi),
  notifications (réception, marquage lu), badges (mobile).
- Assistant Uni : question sur l'emploi du temps, réponse hors ligne
  dégradée, synthèse vocale activable / désactivable (web).

**Hors ligne (mobile)**
- Consulter emploi du temps, cours, notes sans réseau ; rendre un devoir
  et envoyer un message sans réseau puis vérifier qu'ils partent au retour
  du réseau ; couper le réseau pendant la synchronisation ; passer une nuit
  fermé puis rouvrir sans réseau.

**Administration (web)**
- Structure académique : toutes les filières et niveaux apparaissent, y
  compris ICT4D L2 et L3 fictives ; l'administration n'est liée à aucune
  filière en particulier.
- Paiements : chaque bouton d'abonnement ouvre WhatsApp au bon numéro avec
  le bon message, aucun formulaire de carte ; la page des validations en
  attente liste bien la demande.
- Applications à télécharger : seul le super-admin peut modifier les liens ;
  la page `/#/download` reflète la modification.

**Pages publiques (web)**
- Landing (statistiques dynamiques), À propos, Équipe (dix membres, photos,
  cartes), Présentation (vidéo qui se lance), Tarifs, Contact (numéro
  correct), Télécharger, pied de page ; responsive sur petit écran ; aucune
  erreur de sécurité de contenu dans la console ; temps de chargement.

### Limites connues à ne pas signaler comme bogues

Emplois du temps ICT4D L2/L3 fictifs ; APK signé en debug (avertissement
d'installation) ; adresses web en `/#/` ; desktop non publié ; pas de
visioconférence sur web et mobile ; paiement uniquement par WhatsApp.

### Ce que je te demande aussi de produire pour ce groupe

- Un **modèle de rapport de bogue** (titre, plateforme et version, compte
  et rôle, étapes, attendu, obtenu, capture, fréquence, gravité :
  bloquant / majeur / mineur / cosmétique) et l'endroit où les consigner
  (issues GitHub des dépôts `uniflow-we` et `uniflow-mobile`, un rapport
  par bogue, étiquettes par gravité).
- Un **rituel de triage** quotidien : qui lit les rapports, qui corrige
  (William, Hassane et Ange peuvent corriger les Functions et le schéma ;
  Judith et Sandra le mobile ; moi le web), comment on revérifie un bogue
  corrigé, et la règle « aucun bloquant ouvert à J7 ».
- Une **feuille de suivi** (tableau : simulation, testeur, jour, résultat,
  bogues liés).

---

## 6. Rythme commun et livrables de fin de semaine

- **Point quotidien de 15 minutes** (heure `[À COMPLÉTER]`), trois groupes
  ensemble : fait hier, prévu aujourd'hui, blocages.
- **J4 (vendredi 25/09)** : revue de mi-parcours — démonstration desktop,
  montage de la vidéo en brouillon, bilan des bogues trouvés et corrigés ;
  réajustement du plan pour J5-J7.
- **J7 (lundi 28/09)** : démonstration finale et bilan. Livrables attendus :
  binaire desktop téléchargeable depuis le site ; vidéo publiée (16:9 et
  9:16) ; chaîne TikTok active avec cinq vidéos ; calendrier de diffusion
  exécuté et tableau des réactions ; campagne de tests jouée, tous les
  rapports de bogue triés, aucun bloquant ouvert ; journaux
  `ETAT-DU-PROJET.md` et `TRAVAUX-RESTANTS.md` mis à jour.

---

## 7. Forme attendue de ta réponse

1. **Résumé exécutif** (10 lignes) : objectifs de la semaine, les trois
   groupes, les jalons J4 et J7.
2. **Vue d'ensemble J1 → J7** : un tableau, une ligne par jour, une colonne
   par groupe.
3. **Plan détaillé par groupe**, jour par jour (tâches, responsable, durée,
   livrable, critère de terminé, dépendances).
4. **Campagne de tests complète** (§5) : liste ordonnée des simulations avec
   leurs étapes, répartition par jour et par testeur, modèle de rapport,
   rituel de triage, feuille de suivi.
5. **Risques et parades** (ex. : Windows sans machine de compilation, retard
   du hors ligne desktop, accord des personnes filmées, bogue bloquant
   découvert à J6).
6. **Définition de « terminé »** pour chaque groupe.
7. **Questions à me poser** pour tout ce que tu as marqué `[À CONFIRMER]`.

Sois précis, sobre, sans emoji. Si une tâche te semble impossible en
7 jours avec ces effectifs, dis-le et propose ce qu'on reporte plutôt que de
tout caser.
